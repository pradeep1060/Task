package com.cg.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cg.model.UserPage;

public interface UserRepository extends MongoRepository<UserPage, Integer>{
	
	public boolean existByEmail(String email);
}
