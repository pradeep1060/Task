package com.cg.model;

import org.springframework.data.annotation.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
public class UserPage {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int empId;
	private String Email;
	private String corpId;
	private String projectName;
	private int projectCode;
	private String managerEmail;
	private String password;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getCorpId() {
		return corpId;
	}
	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public int getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(int projectCode) {
		this.projectCode = projectCode;
	}
	public String getManagerEmail() {
		return managerEmail;
	}
	public void setManagerEmail(String managerEmail) {
		this.managerEmail = managerEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public UserPage(int id, int empId, String email, String corpId, String projectName, int projectCode,
			String managerEmail, String password) {
		super();
		this.id = id;
		this.empId = empId;
		Email = email;
		this.corpId = corpId;
		this.projectName = projectName;
		this.projectCode = projectCode;
		this.managerEmail = managerEmail;
		this.password = password;
	}
	
	
	@Override
	public String toString() {
		return "UserPage [id=" + id + ", empId=" + empId + ", Email=" + Email + ", corpId=" + corpId + ", projectName="
				+ projectName + ", projectCode=" + projectCode + ", managerEmail=" + managerEmail + ", password="
				+ password + "]";
	}
	
	
	public UserPage() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
