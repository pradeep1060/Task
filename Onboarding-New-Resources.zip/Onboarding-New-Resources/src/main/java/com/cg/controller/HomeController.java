package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.cg.model.UserPage;
import com.cg.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
//	private UserService userSer;
	private UserService userService;
	
	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/Login")
	public String login() {
		return "login";
	}

	@GetMapping("/User")
	public String user() {
		return "user";
	}
	
		@PostMapping("/createUser")
		public String createUser(@ModelAttribute UserPage user){

			//			System.out.println(user);
			
			boolean f= userService.checkEmail(user.getEmail());
			if(f) {
				System.out.println("Email id already Exist");
			}else {
				
			
			UserPage userpage=userService.createUser(user);
			if(user != null) {
				System.out.println("User Registerd Sucessfully");
			} else {
				System.out.println("Something Went Wrong");
				}
	}
			return "redirect:/user";
		}
	
}
