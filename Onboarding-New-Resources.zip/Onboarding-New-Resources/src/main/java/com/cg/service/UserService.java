package com.cg.service;

import com.cg.model.UserPage;

public interface UserService{
	
	public UserPage createUser(UserPage user);
	
	public boolean checkEmail(String email);

}
