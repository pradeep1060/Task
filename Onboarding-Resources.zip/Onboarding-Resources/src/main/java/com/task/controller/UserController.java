package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.Exceptions.UserAlreadyExistException;
import com.task.model.User;
import com.task.model.UserLogin;
import com.task.service.UserService;

@RestController
@RequestMapping("api/v1")
public class UserController {
	
	@Autowired
	private UserService userRepo;
	
	@Autowired
	public UserController(UserService userRepo) {
        this.userRepo = userRepo;
	}
	
	@PostMapping("/createUser")
    public ResponseEntity<User> createUser(@RequestBody User user) throws UserAlreadyExistException{
       User saveduser = userRepo.createUser(user);
       return new ResponseEntity<>(saveduser, HttpStatus.CREATED);
   }

	@GetMapping("/Userlogin")
    public String userLogin(@RequestBody UserLogin userlogin) {
        List<User> al=userRepo.getAllUsers();
        boolean status=false;
        for(User u:al) {
        	if(u.getEmail().equals(userlogin.getEmail())&&u.getPassword().equals(userlogin.getPassword())){
                status=true;
            }
        }

        if(status==true) {
            return "welcome User";
        }
        else  {
            return "Invalid Details Please Register";
        	}
		} 
		
	@GetMapping("/getAllUser")
    public ResponseEntity<List<User>> getAllUsers(){
    return new ResponseEntity<List<User>>((List<User>)userRepo.getAllUsers(),HttpStatus.OK);
    }

}
