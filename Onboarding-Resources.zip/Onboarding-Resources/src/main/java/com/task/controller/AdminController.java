package com.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.task.Exceptions.AdminAlreadyExistException;
import com.task.Exceptions.AdminUpdatedException;
import com.task.model.Admin;
import com.task.service.AdminService;

@RestController
@RequestMapping("api/v1")
public class AdminController {

	
	@Autowired
	private AdminService adser;
	
	@PostMapping("/addResource")
	public ResponseEntity<Admin> addResource(@RequestBody Admin admin) throws AdminAlreadyExistException {
		Admin savedadmin = adser.addResource(admin);
		return new ResponseEntity<>(savedadmin, HttpStatus.CREATED);
	}
	
	
	@PutMapping("/updateResource/{id}")
	public Admin updateResource(@RequestBody Admin admin,@PathVariable("id")Long id)throws AdminUpdatedException{
		return adser.updateResource(admin, id);
	
	} 
	@DeleteMapping("/deleteResource/{id}")
	public ResponseEntity<?>deleteResource(@RequestBody Admin admin,@PathVariable("id")Long id) {
		adser.deleteResource(admin);
		return ResponseEntity.ok("Resource Deleted By Admin");
	}
	@GetMapping("/getAllResource")
	public ResponseEntity<List<Admin>> getAllResource() {
		return new ResponseEntity<List<Admin>>((List<Admin>)adser.getAllResource(),HttpStatus.OK);
	}
	
	}
