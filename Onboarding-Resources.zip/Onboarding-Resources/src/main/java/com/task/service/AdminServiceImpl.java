package com.task.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import com.task.Exceptions.AdminAlreadyExistException;
import com.task.Exceptions.AdminUpdatedException;
import com.task.model.Admin;
import com.task.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminRepository admRep;
	
	@Autowired
	private MongoRepository<Admin, Long> adRep;
	
//	Parameterized constructor
	public AdminServiceImpl(AdminRepository admRep) {
		super();
		this.admRep = admRep;
	}

	@Override
	public Admin addResource(Admin admin) throws AdminAlreadyExistException {
		if(admRep.existsById(admin.getId()) ) {
			throw new AdminAlreadyExistException();
		}
		Admin savedadmin = admRep.save(admin);
		return savedadmin; 
		
	}

	@Override
	public Admin updateResource(Admin admin, Long id) throws AdminUpdatedException {
		Optional<Admin> OnboardingResource = this.admRep.findById(admin.getId());
		if(OnboardingResource.isPresent()) {
			Admin updateResource = OnboardingResource.get();
			updateResource.setId(admin.getId());
            updateResource.setEmpId(admin.getEmpId());
            updateResource.setEmail(admin.getEmail());
            updateResource.setCorpId(admin.getCorpId());
            updateResource.setProjectName(admin.getProjectName());
            updateResource.setProjectCode(admin.getProjectCode());
            updateResource.setManagerEmail(admin.getManagerEmail());
            updateResource.setPassword(admin.getPassword());     
        admRep.save(admin);
        return admin;
			
		}
		else
		{
			throw new AdminUpdatedException();
		}
	}

	@Override
	public String deleteResource(Admin admin) {
		admRep.delete(admin);
		return "Admin Deleted the Resource";
	}

	@Override
	public List<Admin> getAllResource() {
		return (List<Admin>)admRep.findAll();
	}

}
