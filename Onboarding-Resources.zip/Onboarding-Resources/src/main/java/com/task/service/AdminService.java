package com.task.service;

import java.util.List;

import com.task.Exceptions.AdminAlreadyExistException;
import com.task.Exceptions.AdminUpdatedException;
import com.task.model.Admin;

public interface AdminService {
	
	public Admin addResource(Admin admin) throws AdminAlreadyExistException;
	public Admin updateResource(Admin admin, Long id) throws AdminUpdatedException;
	public String deleteResource(Admin admin);
	public List<Admin> getAllResource();

}
