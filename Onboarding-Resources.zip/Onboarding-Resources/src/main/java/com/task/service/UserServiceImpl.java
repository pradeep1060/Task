package com.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import com.task.repository.UserRepository;
import com.task.Exceptions.UserAlreadyExistException;
import com.task.model.User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private MongoRepository<User, Integer> userRep;

	@Override
	public User createUser(User user) throws UserAlreadyExistException {
		
		if(userRepo.existsById(user.getId())) {
			throw new UserAlreadyExistException();
		}
		User saveduser = userRepo.save(user);
		return saveduser;
	}

	@Override
	public List<User> getAllUsers() {
		return (List<User>) userRepo.findAll();
	}


}
