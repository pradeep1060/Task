package com.task.service;

import java.util.List;

import com.task.Exceptions.UserAlreadyExistException;
import com.task.model.User;

public interface UserService {
	
	
	public User createUser(User user) throws UserAlreadyExistException;
	
	public List<User> getAllUsers();


}
