package com.task.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


@Document(collection="Admin")
public class Admin {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank
	private String username;
	@NotBlank
	private int empId;
	@Email
	private String email;
	@NotBlank
	@Indexed(unique = true)
	private String corpId;
	@NotBlank
	private String projectName;
	@NotBlank
	private int projectCode;
	@Email
	private String managerEmail;
	@Size(min=8, max=12)
	private String password;
	
	
//	getters and setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCorpId() {
		return corpId;
	}
	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public int getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(int projectCode) {
		this.projectCode = projectCode;
	}
	public String getManagerEmail() {
		return managerEmail;
	}
	public void setManagerEmail(String managerEmail) {
		this.managerEmail = managerEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
//	Constructor
	public Admin(Long id, @NotBlank String username, @NotBlank int empId, @Email String email, @NotBlank String corpId,
			@NotBlank String projectName, @NotBlank int projectCode, @Email String managerEmail,
			@Size(min = 8, max = 12) String password) {
		super();
		this.id = id;
		this.username = username;
		this.empId = empId;
		this.email = email;
		this.corpId = corpId;
		this.projectName = projectName;
		this.projectCode = projectCode;
		this.managerEmail = managerEmail;
		this.password = password;
	}
	
//	toString
	@Override
	public String toString() {
		return "Admin [id=" + id + ", username=" + username + ", empId=" + empId + ", email=" + email + ", corpId="
				+ corpId + ", projectName=" + projectName + ", projectCode=" + projectCode + ", managerEmail="
				+ managerEmail + ", password=" + password + "]";
	}
	
	
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
