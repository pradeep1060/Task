package com.task.Exceptions;

public class AdminAlreadyExistException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
