package com.task.Exceptions;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@Value(value="${data.exception.msg}")
    private String msg;
    
    @ExceptionHandler(value = UserAlreadyExistException.class)
    public ResponseEntity<String> UserAlreadyExistException(UserAlreadyExistException rap){
            return new ResponseEntity<String>(msg, HttpStatus.CONFLICT);
       
    }
    
    
    @Value(value="${data.exception.msg1}")
    private String msg1;
    
    @ExceptionHandler(value = AdminUpdatedException.class)
    public ResponseEntity<String> AdminUpdatedException(AdminUpdatedException uap){
            return new ResponseEntity<String>(msg1, HttpStatus.CONFLICT);
   
    }

    @Value(value="${data.exception.msg2}")
    private String msg2;
    
    @ExceptionHandler(value = AdminAlreadyExistException.class)
    public ResponseEntity<String> AdminAlreadyExistException(AdminAlreadyExistException aap){
            return new ResponseEntity<String>(msg2, HttpStatus.CONFLICT);
       
    }


}
