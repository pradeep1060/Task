package com.task.Exceptions;

public class AdminUpdatedException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminUpdatedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminUpdatedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
