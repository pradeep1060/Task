package com.task.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.task.model.Admin;

public interface AdminRepository extends MongoRepository<Admin, Long>{

}
