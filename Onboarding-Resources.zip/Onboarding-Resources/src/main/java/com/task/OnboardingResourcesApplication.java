package com.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnboardingResourcesApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnboardingResourcesApplication.class, args);
	}

}
